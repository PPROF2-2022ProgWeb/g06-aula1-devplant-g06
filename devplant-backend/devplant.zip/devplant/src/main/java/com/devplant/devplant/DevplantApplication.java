package com.devplant.devplant;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DevplantApplication {

	public static void main(String[] args) {
		SpringApplication.run(DevplantApplication.class, args);
	}

}
