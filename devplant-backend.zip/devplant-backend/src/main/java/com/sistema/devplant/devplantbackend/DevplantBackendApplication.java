package com.sistema.devplant.devplantbackend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DevplantBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(DevplantBackendApplication.class, args);
	}

}
